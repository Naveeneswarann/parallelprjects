package com.cg.dao;

import java.sql.SQLException;
import java.util.Map;


import com.cg.bean.Account;
import com.cg.exception.BankException;

public interface BankDAO {

	Account showbalance(int number) throws SQLException, ClassNotFoundException, BankException;

	void addcustomer(int accno, Account ab) throws ClassNotFoundException, SQLException;

	Account getAccountToAdd(int target) throws ClassNotFoundException, SQLException, BankException;

	Account getDetailsForWithdraw(int acc1) throws SQLException, ClassNotFoundException, BankException;

	void getAccountToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankException;

	void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException;

	void storeIntoTransaction(String s, Integer i);

	Map<String, Integer> getTransactionInfo();

}
