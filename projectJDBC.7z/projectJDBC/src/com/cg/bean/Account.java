package com.cg.bean;

public class Account {
	
	private String custName;
	private String mobileno;
	private String branch;
	private double balance;
	
	public Account() {
		super();
		
	}

	public Account(String customerName, String mobileno, String branch, double balance) {
		super();
		this.custName = customerName;
		this.mobileno = mobileno;
		this.branch = branch;
		this.balance = balance;
	}

	public String getCustomerName() {
		return custName;
	}

	public void setCustomerName(String customerName) {
		this.custName = customerName;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getBalance() {
		return balance;
	}

	public double setBalance(double balance) {
		 return this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [customerName=" + custName + ", \nmobileno=" + mobileno + ", \nbranch=" + branch + ", \nbalance=" + balance
				+ "]";
	}
}
