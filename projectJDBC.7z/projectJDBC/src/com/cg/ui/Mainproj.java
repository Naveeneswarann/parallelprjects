package com.cg.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

import com.cg.bean.Account;
import com.cg.exception.BankException;
import com.cg.service.BankService;
import com.cg.service.BankServiceImpl;

public class Mainproj {

	public static void main(String args[]) throws BankException, ClassNotFoundException, SQLException {
		Scanner sc = null;
		BankService bankserv = new BankServiceImpl();
		Account account = new Account();
		String continueChoice = "";

		do {

			System.out.println("\t\t\t*** WELCOME to CG Bank ***\n");

			System.out.println("\t\t\t1. Create");
			System.out.println("\t\t\t2. Show Balance ");
			System.out.println("\t\t\t3. Deposit");
			System.out.println("\t\t\t4. Withdraw");
			System.out.println("\t\t\t5. Fund Transfer");
			System.out.println("\t\t\t6. Print Transactions");
			System.out.println("\t\t\t7. Exit");

			int choice = 0;
			boolean Flag = false;

			do {
				sc = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = sc.nextInt();
					Flag = true;
					switch (choice) {

					/* Create account */

					case 1:
						String custName = "";
						boolean custNameFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter your Name");
							try {
								custName = sc.nextLine();
								bankserv.validateName(custName);
								custNameFlag = true;
								break;
							} catch (BankException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custNameFlag);

						String mobileno = "";
						boolean mobilenoFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter your Mobile Number: ");
							try {
								mobileno = sc.nextLine();
								bankserv.validateCell(mobileno);
								mobilenoFlag = true;
								break;
							} catch (BankException e) {
								mobilenoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobilenoFlag);

						String branchname = "";
						boolean branchnameFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Branch name: ");
							try {
								branchname = sc.nextLine();
								bankserv.validateBranch(branchname);
								branchnameFlag = true;
								break;
							} catch (BankException e) {
								branchnameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!branchnameFlag);

						account.setCustomerName(custName);
						account.setMobileno(mobileno);
						account.setBranch(branchname);

						double accbal = 0;
						boolean accFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Initial balance in account: ");
							try {
								accbal = sc.nextInt();
								accFlag = true;
							} catch (InputMismatchException e) {
								accFlag = false;
								System.err.println("Balance should be only digits");
							}
						} while (!accFlag);
						account.setBalance(accbal);
						int accountnumber = (int) (Math.random() * 1000000);
						bankserv.addcustomer(accountnumber, account);
						System.out.println("\t\t Your Account Created Succesfully");
						System.out.println("\n\t\t\tName: " + custName);
						System.out.println("\n\t\t\tBranch: " + branchname);
						System.out.println("\n\t\t\tMobile No: " + mobileno);
						System.out.println("\n\t\t\tAccount number: " + accountnumber);
						System.out.println("\n\t\t\tAccount Balance: " + accbal);
						break;

					/* Show Balance */

					case 2: {
						int acc = 0;
						boolean accflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number To Get The Balance: ");
							try {
								acc = sc.nextInt();
								Account ab = bankserv.showbalance(acc);
								System.out.println("the balance in your account is: " + ab.getBalance());
								String s = "The balance in your Account is: ";
								Integer i = (int) ab.getBalance();
								bankserv.storeIntoprintTransaction(s, i);
								accflag = true;
							} catch (InputMismatchException e) {
								accflag = false;
								System.err.println("Account number should be only digits");
							} catch (BankException e) {
								accflag = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag);
						break;
					}

					/* Deposit */

					case 3: {
						double depositamnt = 0;
						boolean depflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter the deposit amount : ");
							try {
								depositamnt = sc.nextDouble();
								depflag = true;
							} catch (InputMismatchException e) {
								depflag = false;
								System.err.println("Amount should be in digits");
							}
						} while (!depflag);

						int target = 0;
						boolean targetflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter the Account number to deposit: ");
							try {
								target = sc.nextInt();
								Account bc = bankserv.getAccountToAdd(target);
								System.out.println("Current balance in account is: " + bc.getBalance());
								double add = bc.getBalance();
								double total = add + depositamnt;
								bc.setBalance(total);
								bankserv.getAccToAdded(total, target);
								String s1 = "Current balance in account is ";
								Integer i1 = (int) add;
								bankserv.storeIntoprintTransaction(s1, i1);
								System.out.println("Updated balance Account is: " + total);
								String s7 = "Updated balance in Account = ";
								Integer i7 = (int) total;
								bankserv.storeIntoprintTransaction(s7, i7);
								targetflag = true;
							} catch (InputMismatchException e) {
								targetflag = false;
								System.err.println("Account number should be in digits");
							} catch (BankException e) {
								targetflag = false;
								System.err.println("Invalid Account number");
							}
						} while (!targetflag);
						break;
					}
					// Withdraw amount

					case 4: {

						double money = 0;
						boolean moneyflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter the Withdraw Amount ");
							try {
								money = sc.nextDouble();
								moneyflag = true;
							} catch (InputMismatchException e) {
								moneyflag = false;
								System.err.println("Amount should be in digits");
							}
						} while (!moneyflag);

						int acc1 = 0;
						boolean accflag1 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number to withdraw: ");
							try {
								acc1 = sc.nextInt();
								Account cd = bankserv.getDetailsForWithdraw(acc1);
								double d = cd.getBalance();
								System.out.println("Current balance in the  account is: " + d);
								if (d > money) {
									double d1 = account.setBalance(d - money);
									bankserv.getDetailsForWithdraw(d1, acc1);
									System.out.println("Updated balance in account is: " + d1);
									String s3 = "Current balance in Account is: ";
									Integer i3 = (int) cd.getBalance();
									bankserv.storeIntoprintTransaction(s3, i3);
									String s8 = "Updated balance in Account is ";
									Integer i8 = (int) d1;
									bankserv.storeIntoprintTransaction(s8, i8);
								} else {
									System.out.println("Insufficient balance");
								}
								accflag1 = true;
							} catch (InputMismatchException e) {
								accflag1 = false;
								System.err.println("Account number should be only digits");
							} catch (BankException e) {
								accflag1 = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag1);

						break;
					}

					/* Fund transfer */

					case 5: {
						double money1 = 0;
						boolean moneyflag1 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter transfer amount: ");
							try {
								money1 = sc.nextDouble();
								moneyflag1 = true;
							} catch (InputMismatchException e) {
								moneyflag1 = false;
								System.err.println("Amount should be only digits");
							}
						} while (!moneyflag1);

						int acc2 = 0;
						boolean accflag2 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number from which money to be transferred: ");
							try {
								acc2 = sc.nextInt();
								Account de = bankserv.showbalance(acc2);
								double d3 = de.getBalance();
								System.out.println("Current balance in the Sender Account is: " + d3);
								String s9 = "Current balance in the Sender Account is ";
								Integer i9 = (int) d3;
								bankserv.storeIntoprintTransaction(s9, i9);
								double d4 = d3 - money1;
								bankserv.getDetailsForWithdraw(d4, acc2);
								System.out.println(" Updated balance in the Sender Account: " + d4);
								String s4 = "Updated balance in the Sender Account is ";
								Integer i4 = (int) d4;
								bankserv.storeIntoprintTransaction(s4, i4);
								accflag2 = true;
							} catch (InputMismatchException e) {
								accflag2 = false;
								System.err.println("Account number should be only digits");
							} catch (BankException e) {
								accflag2 = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag2);

						int acc3 = 0;
						boolean accflag3 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number to which money to be transferred: ");
							try {
								acc3 = sc.nextInt();
								Account ef = bankserv.showbalance(acc3);
								double d5 = ef.getBalance();
								System.out.println("The Present balance in the Receiver Account is: " + d5);
								String s10 = "The Present balance in the Receiver Account is ";
								Integer i10 = (int) d5;
								bankserv.storeIntoprintTransaction(s10, i10);
								double d6 = d5 + money1;
								bankserv.getDetailsForWithdraw(d6, acc3);
								System.out.println(
										"The Updated balance in the Receiver Account from Sender Account is: " + d6);
								String s5 = "The Updated balance in the Receiver Account from Sender Account is ";
								Integer i5 = (int) d6;
								bankserv.storeIntoprintTransaction(s5, i5);
								accflag3 = true;
							} catch (InputMismatchException e) {
								accflag3 = false;
								System.err.println("Input should be digits");
							} catch (BankException e) {
								accflag3 = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag3);
						break;
					}

					/*print transactions*/

					case 6: {
						Map<String, Integer> map = bankserv.getTransactionInfo();
						System.out.println("!!!! Transaction done!!!! ");
						System.out.println("");
						for (Entry<String, Integer> entry : map.entrySet()) {
							System.out.println(entry.getKey() + "" + entry.getValue());
						}
						break;
					}

					/*Exit */

					case 7:
						System.out.println("****** THANK YOU for Using CG bank ******* ");
						System.exit(0);
						break;

					default:
						Flag = false;
						System.out.println("Input should be from the above numbers only");
						break;
					}
				} catch (InputMismatchException e) {
					Flag = false;
					System.err.println("please enter only digits");
				}

			} while (!Flag);

			sc = new Scanner(System.in);
			System.out.println(" continue again??? [y/n]");
			continueChoice = sc.nextLine();

		} while (continueChoice.equalsIgnoreCase("y"));
		sc.close();
	}
}
