package com.cg.service;

import java.sql.SQLException;
import java.util.Map;


import com.cg.bean.Account;
import com.cg.exception.BankException;

public interface BankService {

	void validateName(String custName) throws BankException;

	void validateCell(String cellno) throws BankException;

	void validateBranch(String branchname) throws BankException;

	void addcustomer(int accountnumber, Account account) throws BankException, ClassNotFoundException, SQLException;

	Account showbalance(int number) throws BankException, ClassNotFoundException, SQLException;

	Account getAccountToAdd(int target)throws BankException, ClassNotFoundException, SQLException;

	Account getDetailsForWithdraw(int acc1)throws BankException, SQLException, ClassNotFoundException;

	void getAccToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankException;

	void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException;

	void storeIntoprintTransaction(String s, Integer i);

	Map<String, Integer> getTransactionInfo();

	

}
