package com.cg.service;

import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Pattern;


import com.cg.bean.Account;
import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;
import com.cg.exception.BankException;

public class BankServiceImpl implements BankService {
	
	BankDAO dao=new BankDAOImpl();

	@Override
	public void validateName(String custName) throws BankException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, custName)) {
			throw new BankException("First letter should be capital and length must be in between 5 to 20");
		}
		
	}

	@Override
	public void validateCell(String mobileno) throws BankException {
		String nameRegEx = "[7|8|9]{1}[0-9]{9}";
		if(!Pattern.matches(nameRegEx, mobileno)) {
			throw new BankException("mobile number should be 10 digits");
		}
	}

	@Override
	public void validateBranch(String branchname) throws BankException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, branchname)) {
			throw new BankException("Please Enter valid branch name ");
		}
		
	}

	@Override
	public void addcustomer(int accno, Account ab) throws ClassNotFoundException, SQLException {
		dao.addcustomer(accno,ab);
		
	}

	@Override
	public Account showbalance(int number) throws ClassNotFoundException, SQLException, BankException {
		
		Account answer=dao.showbalance(number);
		return answer;
		
	}

	@Override
	public Account getAccountToAdd(int target) throws ClassNotFoundException, SQLException, BankException {
		
		return dao.getAccountToAdd(target);
	}

	@Override
	public Account getDetailsForWithdraw(int acc1) throws SQLException, ClassNotFoundException, BankException {
		
		return dao.getDetailsForWithdraw(acc1);
	}

	@Override
	public void getAccToAdded(double total, int target) throws ClassNotFoundException, SQLException, BankException {
		
		dao.getAccountToAdded(total,target);
		
	}

	@Override
	public void getDetailsForWithdraw(double d1, int acc1) throws SQLException, ClassNotFoundException {
		
		dao.getDetailsForWithdraw(d1,acc1);
		
	}

	@Override
	public void storeIntoprintTransaction(String s, Integer i) {
		dao.storeIntoTransaction(s,i);
		
	}

	@Override
	public Map<String, Integer> getTransactionInfo() {
		
		Map<String,Integer>ans=dao.getTransactionInfo();
				
		return ans;
	}

}
