package com.cg.exception;

public class BankingException extends Exception {
	
	public BankingException(String s) {
		super(s);
	}

}
