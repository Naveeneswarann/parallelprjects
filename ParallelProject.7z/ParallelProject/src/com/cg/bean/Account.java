package com.cg.bean;

public class Account {
	
	private String CustomerName;
	private String Customermobileno;
	private String Bankbranch;
	private double Initalbalance;
	
	public Account() {
		super();
		
	}

	public Account(String custName, String mobileno, String branch, double balance) {
		super();
		this.CustomerName = custName;
		this.Customermobileno = mobileno;
		this.Bankbranch = branch;
		this.Initalbalance = balance;
	}

	public String getCustName() {
		return CustomerName;
	}

	public void setCustName(String custName) {
		this.CustomerName = custName;
	}

	public String getCellno() {
		return Customermobileno;
	}

	public void setCellno(String mobileno) {
		this.Customermobileno = mobileno;
	}

	public String getBranch() {
		return Bankbranch;
	}

	public void setBranch(String branch) {
		this.Bankbranch = branch;
	}

	public double getBalance() {
		return Initalbalance;
	}

	public double setBalance(double balance) {
		 return this.Initalbalance = balance;
	}

	@Override
	public String toString() {
		return "Account [custName=" + CustomerName + ",mobileno=" + Customermobileno + ", branch=" + Bankbranch + ", balance=" + Initalbalance
				+ "]";
	}
}
