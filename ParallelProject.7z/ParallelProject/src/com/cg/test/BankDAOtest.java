package com.cg.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.Account;
import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;

public class BankDAOtest {

	BankDAO dao=new BankDAOImpl();
	@Before
	public void setUp() throws Exception {
		dao = new BankDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
	}
	@Test
	public void testAddCustomer() {

		Account ab = new Account("Anish","TVM","8056957706" ,55000d);


		int genId = dao.addcustomer(1234,ab);
	
         assertNotNull(genId);
	}
	}


