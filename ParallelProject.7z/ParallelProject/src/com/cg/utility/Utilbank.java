package com.cg.utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Account;
import com.cg.exception.BankingException;

public class Utilbank {
	
	static HashMap<Integer,Account> account=new HashMap<Integer,Account>();
	static Map<String,Integer> trans=new HashMap<String,Integer>();
	
	static {
		account.put(1, new Account("krishna","7013752882","chennai",10000));
		account.put(2, new Account("kalyan","8951582421","bangalore",40000));
		account.put(3, new Account("nanba","9052235533","hyderabad",35000));
		account.put(4, new Account("arun","8008667199","mumbai",51000));
	}
	
	public static void addcustomer(Integer i, Account account1) {
		account.put(i, account1); 
	}

	public static HashMap<Integer, Account> getAllDetials() {
	    return account;
		}

	public static Map<String, Integer> getTrans() {
		return trans;
	}

	public static void setTrans(Map<String, Integer> trans) {
		Utilbank.trans = trans;
	}
	
	public static void addTransaction(String s,Integer I) {
		trans.put(s, I);
	}

	public static Account showbalance(int number) throws BankingException
	{
		if(account.containsKey(number))
		{
			Account answer=account.get(number);
			return answer;
		}
		else
			throw new BankingException("Invalid Account");
	}
	
	public static Account getAccountToAdd(int target) throws BankingException
	{
		if(account.containsKey(target))
		{
			Account ans=account.get(target);
			return ans;
		}
		else
			throw new BankingException("Invalid Account");
	}

	public static Account getDetailsForWithdraw(int acc1) throws BankingException {
		
		if(account.containsKey(acc1))
		{
			Account ans=account.get(acc1);
			return ans;
		}
		else
			throw new BankingException("Invalid Account");
	}
	
	

}
