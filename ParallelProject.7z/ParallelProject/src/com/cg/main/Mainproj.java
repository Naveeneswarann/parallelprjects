package com.cg.main;

import java.util.InputMismatchException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Scanner;
import com.cg.bean.Account;
import com.cg.exception.BankingException;
import com.cg.service.BankingService;
import com.cg.service.BankingServiceImpl;

public class Mainproj {

	public static void main(String args[]) throws BankingException {
		Scanner sc = null;
		BankingService bankserv = new BankingServiceImpl();
		Account acc= new Account();
		String continueChoice = "";

		do {

			System.out.println("\t\tWELCOME to CG bank");
			System.out.println("\n\tSelect Your Choice");
			System.out.println("\t\t1. Create Account");
			System.out.println("\t\t2. Show balance ");
			System.out.println("\t\t3. Deposit ");
			System.out.println("\t\t4. Withdraw ");
			System.out.println("\t\t5. Fund Transfer");
			System.out.println("\t\t6. Print Transactions");
			System.out.println("\t\t7. Exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				sc = new Scanner(System.in);
				System.out.println("t\tEnter your choice");
				try {
					choice = sc.nextInt();
					choiceFlag = true;
					switch (choice) {

					// create account

					case 1:
						String custName = "";
						boolean custNameFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter customer name");
							try {
								custName = sc.nextLine();
								bankserv.validateName(custName);
								custNameFlag = true;
								break;
							} catch (BankingException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custNameFlag);

						String mobileno = "";
						boolean mobilenoFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Mobile Number: ");
							try {
								mobileno = sc.nextLine();
								bankserv.validateCell(mobileno);
								mobilenoFlag = true;
								break;
							} catch (BankingException e) {
								mobilenoFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!mobilenoFlag);

						String branchname = null;
						boolean branchnameFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Branch name: ");
							try {
								branchname = sc.nextLine();
								bankserv.validateBranch(branchname);
								branchnameFlag = true;
								break;
							} catch (BankingException e) {
								branchnameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!branchnameFlag);

						acc.setCustName(custName);
						acc.setCellno(mobileno);
						acc.setBranch(branchname);

						double accountbalance = 0;
						boolean accountFlag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Account balance: ");
							try {
								accountbalance = sc.nextInt();
								accountFlag = true;
							} catch (InputMismatchException e) {
								accountFlag = false;
								System.err.println("Balance should be only digits");
							}
						} while (!accountFlag);
						acc.setBalance(accountbalance);
						int accountnumber = (int) (Math.random() * 1000);
						bankserv.addcustomer(accountnumber, acc);
						System.out.println("Account Created");
						System.out.println("Name: " + custName);
						System.out.println("Branch: " + branchname);
						System.out.println("Mobile No: " + mobileno);
						System.out.println("Account number: " + accountnumber);
						System.out.println("Account Balance: " + accountbalance);
						break;

					// For balance Enquiry

					case 2: {
						int acct = 0;
						boolean accflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number To Get The Balance");
							try {
								acct = sc.nextInt();
								Account ab = bankserv.showbalance(acct);
								System.out.println("the balance in your account is: " + ab.getBalance());
								String s = "The balance in your Account is: ";
								Integer i = (int) ab.getBalance();
								bankserv.storeIntoTransaction(s, i);
								accflag = true;
							} catch (InputMismatchException e) {
								accflag = false;
								System.err.println("Account number should be only digits");
							} catch (BankingException e) {
								accflag = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag);
						break;
					}

					//  Deposit amount

					case 3: {
						double deposit = 0;
						boolean depositflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter the Amount to be deposited: ");
							try {
								deposit = sc.nextDouble();
								depositflag = true;
							} catch (InputMismatchException e) {
								depositflag = false;
								System.err.println("Deposit Amount should be only digits");
							}
						} while (!depositflag);

						int target = 0;
						boolean targetflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter the Account number of the Amount to deposit: ");
							try {
								target = sc.nextInt();
								Account bc = bankserv.getAccountToAdd(target);
								System.out.println("Present balance in the account is: " + bc.getBalance());
								double add = bc.getBalance();
								double total = add + deposit;
								bc.setBalance(total);
								String s1 = "The balance in the Deposited Account is ";
								Integer i1 = (int) add;
								bankserv.storeIntoTransaction(s1, i1);
								System.out.println("Updated balance is: " + total);
								String s7 = "The Updated balance in the Deposited Account is ";
								Integer i7 = (int) total;
								bankserv.storeIntoTransaction(s7, i7);
								targetflag = true;
							} catch (InputMismatchException e) {
								targetflag = false;
								System.err.println("Account number should be in digits");
							}
						} while (!targetflag);
						break;
					}

					// Withdraw
					case 4: {

						double money = 0;
						boolean moneyflag = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter the Amount to withdraw");
							try {
								money = sc.nextDouble();
								moneyflag = true;
							} catch (InputMismatchException e) {
								moneyflag = false;
								System.err.println("Amount should be only digits");
							}
						} while (!moneyflag);

						int acc1 = 0;
						boolean accflag1 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number To withdraw money: ");
							try {
								acc1 = sc.nextInt();
								Account cd = bankserv.getDetailsForWithdraw(acc1);
								double d = cd.getBalance();
								System.out.println("Present balance in the account is: " + d);
								if (d > money) {
									double d1 = acc.setBalance(d - money);
									System.out.println("Updated balance in the account is: " + d1);
									String s3 = "The balance in the withdraw Account is ";
									Integer i3 = (int) cd.getBalance();
									bankserv.storeIntoTransaction(s3, i3);
									String s8 = "The Updated balance in the withdraw Account is ";
									Integer i8 = (int) d1;
									bankserv.storeIntoTransaction(s8, i8);
								} else {
									System.out.println("Insufficient balance");
								}
								accflag1 = true;
							} catch (InputMismatchException e) {
								accflag1 = false;
								System.err.println("Account number should be only digits");
							} catch (BankingException e) {
								accflag1 = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag1);

						break;
					}

					//  Fund transfer

					case 5: {
						double money1 = 0;
						boolean moneyflag1 = false;
						do {
							sc= new Scanner(System.in);
							System.out.println("Enter the Amount to transfer: ");
							try {
								money1 = sc.nextDouble();
								moneyflag1 = true;
							} catch (InputMismatchException e) {
								moneyflag1 = false;
								System.err.println("Amount should be only digits");
							}
						} while (!moneyflag1);

						int acc2 = 0;
						boolean accflag2 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number from which money to be transferred: ");
							try {
								acc2 = sc.nextInt();
								Account de = bankserv.showbalance(acc2);
								double d3 = de.getBalance();
								String s9 = "The balance in the Sender Account is ";
								Integer i9 = (int) d3;
								bankserv.storeIntoTransaction(s9, i9);
								double d4 = d3 - money1;
								System.out.println("Updated balance in the sender account: " + d4);
								String s4 = "The Updated balance in the Sender Account is ";
								Integer i4 = (int) d4;
								bankserv.storeIntoTransaction(s4, i4);
								accflag2 = true;
							} catch (InputMismatchException e) {
								accflag2 = false;
								System.err.println("Account number should be only digits");
							} catch (BankingException e) {
								accflag2 = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag2);

						int acc3 = 0;
						boolean accflag3 = false;
						do {
							sc = new Scanner(System.in);
							System.out.println("Enter Your Account Number to which money to be transferred: ");
							try {
								acc3 = sc.nextInt();
								Account ef = bankserv.showbalance(acc3);
								double d5 = ef.getBalance();
								String s10 = "The balance in the Receiver Account is ";
								Integer i10 = (int) d5;
								bankserv.storeIntoTransaction(s10, i10);
								double d6 = d5 + money1;
								System.out.println("Updated balance in the Receiver account: " + d6);
								String s5 = "The Updated balance in the Receiver Account from Sender Account is ";
								Integer i5 = (int) d6;
								bankserv.storeIntoTransaction(s5, i5);
								accflag3 = true;
							} catch (InputMismatchException e) {
								accflag3 = false;
								System.err.println("Input should be digits");
							} catch (BankingException e) {
								accflag3 = false;
								System.err.println(e.getMessage());

							}
						} while (!accflag3);
						break;
					}

					// Print transactions

					case 6: {
						Map<String, Integer> map = bankserv.getTransactionInfo();
						for (Entry<String, Integer> entry : map.entrySet()) {
							System.out.println(entry.getKey() + "" + entry.getValue());
						}
						break;
					}

					// Exit 

					case 7:
						System.out.println("--Thank you for using CG bank----- ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("Input should be 1,2,3,4,5,6 or 7");
						break;
					}
				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			sc = new Scanner(System.in);
			System.out.println("do you want to continue again [y/n]");
			continueChoice = sc.nextLine();

		} while (continueChoice.equalsIgnoreCase("y"));
		sc.close();
	}
}