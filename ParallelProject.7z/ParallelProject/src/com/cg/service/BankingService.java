package com.cg.service;

import java.util.Map;

import com.cg.bean.Account;
import com.cg.exception.BankingException;

public interface BankingService {


	void addcustomer(int accno, Account ab)throws BankingException;

	Account showbalance(int number)throws BankingException;

	void validateBranch(String branchname)throws BankingException;

	void validateCell(String cellno)throws BankingException;

	void validateName(String custName)throws BankingException;

	Account getAccountToAdd(int target) throws BankingException;

	Account getDetailsForWithdraw(int acc1) throws BankingException;

	Map<String, Integer> getTransactionInfo() throws BankingException;

	void storeIntoTransaction(String s, Integer i)throws BankingException;

	

	
	

	

	
	
	
	
	
	

}
