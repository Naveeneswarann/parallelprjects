package com.cg.dao;

import java.util.Map;

import com.cg.bean.Account;
import com.cg.exception.BankingException;

public interface BankDAO {

	int addcustomer(int accno, Account ab);

	Account showbalance(int acc) throws BankingException;

	Account getAccountToAdd(int target) throws BankingException;

	Account getDetailsForWithdraw(int acc1)throws BankingException;

	Map<String, Integer> getTransactionInfo()throws BankingException;

	void storeIntoTransaction(String s, Integer i)throws BankingException;
	
	

}
