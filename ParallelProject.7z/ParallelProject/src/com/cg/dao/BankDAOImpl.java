package com.cg.dao;

import java.util.Map;

import com.cg.bean.Account;
import com.cg.exception.BankingException;
import com.cg.utility.Utilbank;

public class BankDAOImpl implements BankDAO {

	@Override
	public int addcustomer(int accno, Account ab) {
		Utilbank.addcustomer(accno, ab);
		return 0;
	}

	@Override
	public Account showbalance(int number) throws BankingException {
		Account answer=Utilbank.showbalance(number);
		return answer;
	}

	@Override
	public Account getAccountToAdd(int target) throws BankingException {
		
		return Utilbank.getAccountToAdd(target);
	}

	@Override
	public Account getDetailsForWithdraw(int acc1) throws BankingException {
		
		return Utilbank.getDetailsForWithdraw(acc1);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() throws BankingException {
	
		return Utilbank.getTrans();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) throws BankingException {
		Utilbank.addTransaction(s, i);
	}
	
	
	

}
